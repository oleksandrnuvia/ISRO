import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.setViewPortSize(1800, 1000)

WebUI.navigateToUrl('http://85.255.11.51/qa/ims/ujv/1.02.32-UJV/0333f71/#/auth/login')

WebUI.setText(findTestObject('Object Repository/Login/Page_ISRO/input_Pihlaovac jmno_username'), 'odelie')

WebUI.setEncryptedText(findTestObject('Object Repository/Login/Page_ISRO/input_Heslo_password'), '9txfWbx3RHoTNzGZGTQTmQ==')

WebUI.click(findTestObject('Object Repository/Login/Page_ISRO/button_Pihlsit'))

WebUI.click(findTestObject('Object Repository/Login/Page_ISRO/a_Oleksandr Deliergiyev'))

WebUI.verifyElementAttributeValue(findTestObject('Object Repository/Login/Page_ISRO/Page_ISRO/i_Aktivovat admin prva_fa fa-unlock fa-fw'), 
    'class', 'fa fa-unlock fa-fw', 10)

WebUI.closeBrowser()

