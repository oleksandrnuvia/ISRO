<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>REGRESSION</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>0b3ae3f3-1873-46ed-abdc-ab6c33e839ab</testSuiteGuid>
   <testCaseLink>
      <guid>22aff826-1825-4df1-9076-8f0e16089640</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Přihlásit/ISRO-1 Login of user</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
